//
//  Tag.swift
//  PhotoFeed
//

import Foundation
import CoreData


class Tag: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
