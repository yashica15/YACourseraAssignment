//
//  Image.swift
//  PhotoFeed
//

import Foundation
import CoreData


class Image: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
